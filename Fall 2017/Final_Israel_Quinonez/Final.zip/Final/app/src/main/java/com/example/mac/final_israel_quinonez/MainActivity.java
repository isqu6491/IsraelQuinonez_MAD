package com.example.mac.final_israel_quinonez;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

   public void burritoGenerator(View view) {
       ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
       boolean meat = toggle.isChecked();
       String text = "";
       Spinner locationSpinner = (Spinner) findViewById(R.id.spinner);
       String location = String.valueOf(locationSpinner.getSelectedItem());
       RadioGroup type = (RadioGroup) findViewById(R.id.radioGroup);
       int food_id = type.getCheckedRadioButtonId();
       TextView bodyText = (TextView) findViewById(R.id.BodytextView);
       Switch gluttenSwitch = (Switch)findViewById(R.id.switch1);
       boolean gluttenFree = gluttenSwitch.isChecked();
       ImageView image =  (ImageView)findViewById(R.id.imageView);
        int imageSelection = 0;


       if (food_id == -1) {

           Context context = getApplicationContext();
           CharSequence textAlert = "Please select either burrito or taco";
           int duration = Toast.LENGTH_SHORT;

           Toast toast = Toast.makeText(context, textAlert, duration);
           toast.show();
       }

       else {

           if (meat) {

               if(gluttenFree){
                   if (food_id == R.id.radioButton1) {

                       switch (location) {

                           case "The Hill":

                               text = "Chicken burrito with corn tortilla at the hill, check out Illegal Pete's";
                               break;

                           case "29th Street":
                               text = "Chicken burrito with corn tortilla at 29th street, check out Chipotle";
                               break;

                           case "Pearl Street":
                               text = "Chicken burrito with corn tortilla at Pearl street, check out Bartaco";
                               break;

                           default:
                               text = "I love chicken burritos with corn tortilla!";


                       }
                       imageSelection = 1;
                   }

                   else {
                       switch (location) {

                           case "The Hill":

                               text = "Chicken tacos with corn tortilla at the hill, check out Illegal Pete's";
                               break;
                           case "29th Street":
                               text = "Chicken tacos with corn tortilla at 29th street, check out Chipotle";
                               break;
                           case "Pearl Street":
                               text = "Chicken tacos with corn tortilla at Pearl street, check out Bartaco";
                               break;

                           default:
                               text = "I love chicken with corn tortilla tacos!";


                       }imageSelection = 2;

                   }

               }

               else {

                   if (food_id == R.id.radioButton1) {

                       switch (location) {

                           case "The Hill":

                               text = "Chicken burrito at the hill, check out Illegal Pete's";
                               break;

                           case "29th Street":
                               text = "Chicken burrito at 29th street, check out Chipotle";
                               break;

                           case "Pearl Street":
                               text = "Chicken burrito at Pearl street, check out Bartaco";
                               break;

                           default:
                               text = "I love chicken burritos!";
                               break;



                       }
                       imageSelection = 1;
                   }

                   else {
                       switch (location) {

                           case "The Hill":

                               text = "Chicken tacos at the hill, check out Illegal Pete's";
                               break;
                           case "29th Street":
                               text = "Chicken tacos at 29th street, check out Chipotle";
                               break;
                           case "Pearl Street":
                               text = "Chicken tacos at Pearl street, check out Bartaco";
                               break;

                           default:
                               text = "I love chicken tacos!";


                       }imageSelection = 2;

                   }
               }




           }

           else {

               if (gluttenFree){

                   if (food_id == R.id.radioButton1) {

                       switch (location) {

                           case "The Hill":

                               text = "Veggie burrito with corn tortilla at the hill, check out Illegal Pete's";
                               break;
                           case "29th Street":
                               text = "Veggie burrito with corn tortilla at 29th street, check out Chipotle";
                               break;
                           case "Pearl Street":
                               text = "Veggie burrito with corn tortilla at Pearl street, check out Bartaco";
                               break;

                           default:
                               text = "I love Veggie burritos with corn tortilla!";

                       }
                       imageSelection = 1;

                   }
                   else {

                       switch (location) {

                           case "The Hill":

                               text = "Veggie taco with corn tortilla at the hill, check out Illegal Pete's";
                               break;
                           case "29th Street":
                               text = "Veggie taco with corn tortilla at 29th street, check out Chipotle";
                               break;
                           case "Pearl Street":
                               text = "Veggie taco with corn tortilla at Pearl street, check out Bartaco";
                               break;

                           default:
                               text = "I love Veggie tacos with corn tortilla!";
                       }
                       imageSelection = 2;


                   }



               }
               else {
                   if (food_id == R.id.radioButton1) {

                       switch (location) {

                           case "The Hill":

                               text = "Veggie burrito at the hill, check out Illegal Pete's";
                               break;
                           case "29th Street":
                               text = "Veggie burrito at 29th street, check out Chipotle";
                               break;
                           case "Pearl Street":
                               text = "Veggie burrito at Pearl street, check out Bartaco";
                               break;

                           default:
                               text = "I love Veggie burritos!";

                       }
                       imageSelection = 1;

                   }
                   else {

                       switch (location) {

                           case "The Hill":

                               text = "Veggie taco at the hill, check out Illegal Pete's";
                               break;
                           case "29th Street":
                               text = "Veggie taco at 29th street, check out Chipotle";
                               break;
                           case "Pearl Street":
                               text = "Veggie taco at Pearl street, check out Bartaco";
                               break;

                           default:
                               text = "I love Veggie tacos!";
                       }imageSelection = 2;


                   }


               }






           }


       }


       bodyText.setText(text);


       if (imageSelection == 1) {
           image.setImageResource(R.drawable.burrito);
       }
       else if (imageSelection == 2){

           image.setImageResource(R.drawable.taco);

       }

       else {

       }


   }








}




package com.example.mac.lab6_israel_quinonez;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class ReceiveNutritionActivity extends AppCompatActivity {

    private String food;
    private String calories;
    private String carbs;
    private String fat;
    private String protein;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_nutrition);

        Intent intent = getIntent();
        food = intent.getStringExtra("foodItem");
        calories = intent.getStringExtra("calorieItem");
        carbs = intent.getStringExtra("carbItem");
        fat = intent.getStringExtra("fatItem");
        protein = intent.getStringExtra("proteinItem");
        Log.i("food received", food);
        Log.i("calories recieved", calories);

        TextView foodView = (TextView) findViewById(R.id.textView4);
        TextView calorieView = (TextView) findViewById(R.id.textView5);
        TextView carbView = (TextView) findViewById(R.id.textView6);
        TextView fatView = (TextView) findViewById(R.id.textView7);
        TextView proteinView = (TextView) findViewById(R.id.textView8);

        foodView.setText(food);
        calorieView.setText(calories);
        carbView.setText(carbs);
        fatView.setText(fat);
        proteinView.setText(protein);

        final ImageButton imageButton = (ImageButton) findViewById(R.id.imageButton2);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                loadWebSite(view);
            }

        };

        imageButton.setOnClickListener(onclick);




    }
    public void loadWebSite(View view){

        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse("https://www.nutrition.gov/subject/whats-in-food"));
        startActivity(intent);

    }
}

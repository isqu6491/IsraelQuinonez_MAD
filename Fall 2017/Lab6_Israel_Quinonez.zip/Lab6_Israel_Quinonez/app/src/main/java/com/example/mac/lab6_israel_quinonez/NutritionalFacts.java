package com.example.mac.lab6_israel_quinonez;

/**
 * Created by Mac on 12/4/17.
 */

public class NutritionalFacts {
    private String food;
    private String calories;
    private String carbs;
    private String fat;
    private String protein;

    private void setNutritionalInfo(Integer foodSpinner){

        switch (foodSpinner){

            case 0:
                food = "Chicken Breast 6oz";
                calories = "240 Calories";
                carbs = "1g Carbs";
                fat = "4g Fat";
                protein = "52g Protein";
                break;

            case 1:
                food = "Rice 100g";
                calories = "145 Calories";
                carbs = "32g Carbs";
                fat = "1g Fat";
                protein = "2g Protein";
                break;
            case 2:
                food = "Steak 6oz";
                calories = "360 Calories";
                carbs = "2g Carbs";
                fat = "8g Fat";
                protein = "25g Protein";
                break;
            case 3:
                food = "Egg";
                calories = "72 Calories";
                carbs = "1g Carbs";
                fat = "5g Fat";
                protein = "6g Protein";
                break;
            case 4:
                food = "Caesar Salad";
                calories = "200 Calories";
                carbs = "10g Carbs";
                fat = "14g Fat";
                protein = "5g Protein";
                break;
            default:
                food = "none";
                calories = "0 Calories";
                carbs = "0g Carbs";
                fat = "0g Fat";
                protein = "0g Protein";







        }

    }
    public void setFood(Integer foodSpinner){
        setNutritionalInfo(foodSpinner);

    }

    public void setCalories(Integer foodSpinner){
        setNutritionalInfo(foodSpinner);

    }

    public void setCarbs(Integer foodSpinner){
        setNutritionalInfo(foodSpinner);

    }

    public void setFat(Integer foodSpinner){
        setNutritionalInfo(foodSpinner);

    }

    public void setProtein(Integer foodSpinner){
        setNutritionalInfo(foodSpinner);

    }

    public String getFood(){
        return food;
    }
    public String getCalories(){
        return calories;
    }
    public String getCarbs(){
        return carbs;
    }
    public String getFat(){
        return fat;
    }
    public String getProtein(){
        return protein;
    }







}

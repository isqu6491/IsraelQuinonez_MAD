package com.example.mac.lab6_israel_quinonez;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    private NutritionalFacts nutritionFacts = new NutritionalFacts();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = (Button) findViewById(R.id.button);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view){
                nutrition(view);

            }
        };

        button.setOnClickListener(onclick);
    }

    private void nutrition(View view){

        Spinner spinner = (Spinner)findViewById(R.id.spinner);

        Integer food = spinner.getSelectedItemPosition();

        nutritionFacts.setFood(food);

        String itemFood = nutritionFacts.getFood();
        String itemCalories = nutritionFacts.getCalories();
        String itemCarbs = nutritionFacts.getCarbs();
        String itemFat = nutritionFacts.getFat();
        String itemProtein = nutritionFacts.getProtein();

        Intent intent = new Intent(this, ReceiveNutritionActivity.class);

        intent.putExtra("foodItem", itemFood);
        intent.putExtra("calorieItem", itemCalories);
        intent.putExtra("carbItem", itemCarbs);
        intent.putExtra("fatItem", itemFat);
        intent.putExtra("proteinItem", itemProtein);

        startActivity(intent);

        Log.i("food", itemFood);
        Log.i("calories", itemCalories);




    }
}

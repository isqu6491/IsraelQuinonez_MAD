//
//  SecondViewController.swift
//  Lab2_Spring
//
//  Created by Israel Quinonez on 2/6/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    @IBAction func tripadvisorButton(_ sender: UIButton) {
        
        if (UIApplication.shared.canOpenURL(URL(string: "tripadvisor://")!)){
            
            UIApplication.shared.open(URL(string: "tripadvisor://")!, options: [:], completionHandler: nil)
            
        }
        
        else{
        UIApplication.shared.open(URL (string: "http://www.tripadvisor.com")! , options: [:], completionHandler: nil)
        }
    }
    
    @IBAction func expediaButton(_ sender: UIButton) {
    
        if (UIApplication.shared.canOpenURL(URL(string: "expedia://")!)){
            
            UIApplication.shared.open(URL(string: "expedia://")!, options: [:], completionHandler: nil)
            
        }
            
        else{
            UIApplication.shared.open(URL (string: "http://www.expedia.com")! , options: [:], completionHandler: nil)
        }
    
    
    
    
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


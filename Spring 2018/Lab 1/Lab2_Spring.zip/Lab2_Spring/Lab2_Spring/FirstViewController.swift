//
//  FirstViewController.swift
//  Lab2_Spring
//
//  Created by Israel Quinonez on 2/6/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource {
  
    
   
    @IBOutlet weak var destinationPicker: UIPickerView!
    @IBOutlet weak var airportLabel: UILabel!
  
    @IBOutlet weak var attractionLabel: UILabel!
   
    let stateComponent = 0
    let cityComponent = 1
    
    var destinations = [String: [String]]()
    var states = [String]()
    var cities = [String]()
    
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 2
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if component == stateComponent{
            return states.count
        }
        else{
            
            return cities.count
        }
    }
    
  

    override func viewDidLoad() {
        super.viewDidLoad()
       
        if let pathURL = Bundle.main.url(forResource: "Cities", withExtension: "plist"){
            
            let plistdecoder = PropertyListDecoder()
            do {
                
                let data = try Data(contentsOf: pathURL)
                
                destinations = try plistdecoder.decode([String: [String]].self, from: data)
                
                states = Array(destinations.keys)
                cities = destinations[states[0]]! as [String]
                
                print(states)
                print(cities)
                
                
                
            }
            
            catch{
                
                print(error)
            }
            
        }
    }
        
        
        
        
        
       
        
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            
            if component == stateComponent{
                
                return states[row]
                
            }
            else {
                
                return cities[row]
            }
            
        }
        
        
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int){
            
            if component == stateComponent{
                
                let selectedState = states[row]
                cities = destinations[selectedState]!
                destinationPicker.reloadComponent(cityComponent)
                destinationPicker.selectRow(0, inComponent: cityComponent, animated: true)
                
            }
                
                let staterow = pickerView.selectedRow(inComponent: stateComponent)
                
                let cityrow = pickerView.selectedRow(inComponent: cityComponent)
            
            if cities[cityrow] == "Austin"{
                
                airportLabel.text = "Austin's airport is ABIA"
                attractionLabel.text = "Austin's Main attraction is Zilker Park!"
                
            }
            else if cities[cityrow] ==  "Huston"{
                
                airportLabel.text = "Huston's airport is IAH"
                attractionLabel.text = "Huston's Main attraction is the Space Center!"
                
                
            }
                
            else if cities[cityrow] ==  "Orlando"{
                
                airportLabel.text = "Orlando's airport is MCO"
                attractionLabel.text = "Orlando's Main attraction is Disney World!"
                
                
            }
            
            else if cities[cityrow] ==  "Miami"{
                
                airportLabel.text = "Miami's airport is MIA"
                attractionLabel.text = "Miami's Main attraction is Miami Beach!"
                
                
            }
                
            else if cities[cityrow] ==  "New York"{
                
                airportLabel.text = "New York's airport is JFK"
                attractionLabel.text = "New York's Main attraction is Central Park!"
                
                
            }
                
            else if cities[cityrow] ==  "Buffalo"{
                
                airportLabel.text = "Buffalo's airport is BUF"
                attractionLabel.text = "Buffalo's Main attraction is Buffalo Zoo!"
                
                
            }
                
            else if cities[cityrow] ==  "Los Angeles"{
                
                airportLabel.text = "Los Angele's airport is LAX"
                attractionLabel.text = "Los Angele's Main attraction is Disneyland!"
                
                
            }
                
            else if cities[cityrow] ==  "San Francisco"{
                
                airportLabel.text = "San Francisco's airport is SFO"
                attractionLabel.text = "San Francisco's Main attraction is The Golden Gate Bridge!"
                
                
            }
           
            
            
            
            
            
            
            
            
            
            
            
            else {
                airportLabel.text = "fail"
            }
              //  airportLabel.text = "You like \(cities[cityrow]) by \(states[staterow])"
                
                
            
            
        }
        
        // Do any additional setup after loading the view, typically from a nib.

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


package com.example.mac.lab6_israel_quinonez;

import android.app.Activity;
import android.app.ListActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.view.View;

public class LiquorCategoryActivity extends ListActivity {

    private String liquortype;

    public void onListItemClick(ListView listView, View view, int position, long id){

        Intent intent = new Intent(LiquorCategoryActivity.this, LiquorActivity.class);
        intent.putExtra("liquorid", (int) id);
        intent.putExtra("liquortype",(String) liquortype );
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        liquortype = i.getStringExtra("liquortype");

        ListView listLiquor = getListView();

        ArrayAdapter<Liquor>listAdapter;

        switch (liquortype){

            case "Bourbon":
                listAdapter = new ArrayAdapter<Liquor>(this, android.R.layout.simple_list_item_1,Liquor.Bourbon);
                break;
            case "Gin":
                listAdapter = new ArrayAdapter<Liquor>(this, android.R.layout.simple_list_item_1,Liquor.Gin);
                break;
            case "Vodka":
                listAdapter = new ArrayAdapter<Liquor>(this, android.R.layout.simple_list_item_1,Liquor.Vodka);
                break;
            default: listAdapter= new ArrayAdapter<Liquor>(this, android.R.layout.simple_list_item_1,Liquor.Bourbon);
        }
        listLiquor.setAdapter(listAdapter);
    }







}

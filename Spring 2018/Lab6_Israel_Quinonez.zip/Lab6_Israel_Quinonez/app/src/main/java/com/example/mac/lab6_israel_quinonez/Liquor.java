package com.example.mac.lab6_israel_quinonez;

/**
 * Created by Mac on 4/5/18.
 */

public class Liquor {
    private String name;
    private int imageResourceID;

    private Liquor(String newname, int newID){
        this.name = newname;
        this.imageResourceID = newID;
    }

    public static final Liquor[]Bourbon ={
            new Liquor("Bourbon Ricky",R.drawable.bourbon_rickey),
            new Liquor("Brown Derby",R.drawable.brown_derby),
            new Liquor("Old Fashioned Bourbon",R.drawable.old_fashioned_bourbon),
            new Liquor("Hot Toddy",R.drawable.hot_toddy),
            new Liquor("New York Sour",R.drawable.new_york_sour)



    };

    public static final Liquor[]Gin={

            new Liquor("Gimlet",R.drawable.gimlet),
            new Liquor("Dry Martini", R.drawable.dry_martini),
            new Liquor("Holland Gin",R.drawable.holland_gin),
            new Liquor("Gin Fizz",R.drawable.fizz_gin),
            new Liquor("Aviation",R.drawable.aviation),

    };

    public static final Liquor[]Vodka={
            new Liquor("Bloody Mary",R.drawable.bloody_mary),
            new Liquor("Gypsy Queen",R.drawable.gypsy_queen),
            new Liquor("Moscow Mule",R.drawable.moscow_mule),
            new Liquor("Vesper",R.drawable.vesper),
            new Liquor("Sex On The Beach",R.drawable.sex_on_the_beach)

    };

    public  String getName(){
        return name;
    }
    public int getImageResourceID(){
        return imageResourceID;
    }
    public String toString(){
        return this.name;
    }

}


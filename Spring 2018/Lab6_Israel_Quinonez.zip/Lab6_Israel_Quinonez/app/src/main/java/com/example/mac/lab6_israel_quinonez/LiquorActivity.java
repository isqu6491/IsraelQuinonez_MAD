package com.example.mac.lab6_israel_quinonez;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class LiquorActivity extends Activity {

    private String liquortype;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liquor);

        int liquornum = (Integer)getIntent().getExtras().get("liquorid");




        liquortype = (String)getIntent().getExtras().get("liquortype");
        Liquor liquor;

        switch (liquortype){

            case "Bourbon":
                liquor = Liquor.Bourbon[liquornum];
                break;

            case  "Gin":
                liquor = Liquor.Gin[liquornum];
                break;

            case "Vodka":
                liquor = Liquor.Vodka[liquornum];
                break;
            default: liquor = Liquor.Bourbon[liquornum];
        }






        ImageView liquorImage= (ImageView)findViewById(R.id.liquorImageView);
        liquorImage.setImageResource(liquor.getImageResourceID());

        TextView liquorName = (TextView)findViewById(R.id.liquor_name);
        liquorName.setText(liquor.getName());

    }
}

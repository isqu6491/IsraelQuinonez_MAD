package com.example.mac.lab6_israel_quinonez;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.view.MenuItem;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> listView, View view, int position, long id) {
                String liquortype = (String) listView.getItemAtPosition(position);
                Intent intent = new Intent(MainActivity.this, LiquorCategoryActivity.class);
                intent.putExtra("liquortype", liquortype);
                startActivity(intent);
            }
        };

        ListView listview = (ListView)findViewById(R.id.listView);
        listview.setOnItemClickListener(itemClickListener);



    }


}

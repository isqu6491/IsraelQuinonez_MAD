package com.example.mac.final_israel_quinonez;

public class Workout {

    private String name;

    private Workout(String newname){
        this.name = newname;

    }

    public final static Workout[] cardio = {
            new Workout("test")

    };



    public String getName() {
        return name;
    }


    public String toString() {
        return this.name;
    }


}



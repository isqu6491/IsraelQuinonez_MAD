package com.example.mac.final_israel_quinonez;

import android.app.ListActivity;
import android.os.Bundle;
import android.app.Activity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.lang.reflect.Array;

public class Main2Activity extends Activity {
    private String workoutType;
   // private Array activities;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        workoutType = getIntent().getStringExtra("workoutType");
        ListView listView = (ListView)findViewById(R.id.list);

        ArrayAdapter<Workout>listAdapter;
       listAdapter = new ArrayAdapter<Workout>(this,android.R.layout.simple_list_item_1,Workout.cardio);
       listView.setAdapter(listAdapter);
    }




}

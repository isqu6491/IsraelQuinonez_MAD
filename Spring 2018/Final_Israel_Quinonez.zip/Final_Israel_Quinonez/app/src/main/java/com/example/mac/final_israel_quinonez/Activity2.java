package com.example.mac.final_israel_quinonez;

import android.app.Activity;
import android.app.ListActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Activity2 extends ListActivity {
    private String workoutType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);


        workoutType = getIntent().getStringExtra("workoutType");
        ListView activitiesList = getListView();
        ArrayAdapter<Workout> listAdapter;
        listAdapter = new ArrayAdapter<Workout>(this,android.R.layout.simple_list_item_1,Workout.cardio);
        activitiesList.setAdapter(listAdapter);
    }
}

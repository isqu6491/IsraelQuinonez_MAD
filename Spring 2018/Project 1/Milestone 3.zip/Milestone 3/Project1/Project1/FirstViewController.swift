//
//  FirstViewController.swift
//  Project1
//
//  Created by Israel Quinonez on 2/27/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UITextFieldDelegate {
    
    @IBOutlet weak var caloriesButton: UIButton!
    @IBOutlet weak var fatButton: UIButton!
    @IBOutlet weak var carbsButton: UIButton!
    
    @IBOutlet weak var proteinButton: UIButton!
    
    @IBOutlet weak var caloriesTextField: UITextField!
    @IBOutlet weak var fatTextField: UITextField!
    @IBOutlet weak var carbsTextField: UITextField!
    @IBOutlet weak var proteinTextField: UITextField!
    
    var caloriesInputed: String?
    var fatInputed: String?
    var carbsInputed: String?
    var proteinInputed: String?
    
    var lessThanCalories = true
    var lessThanProtein = true
    var lessThanCarbs = true
    var lessThanFat = true
    
    
    @IBAction func buttonChange(_ sender: UIButton) {
        if sender.titleLabel?.text == "Less than:"{
            
            sender.setTitle("More than:", for: UIControlState.normal)
            
            
            
        }
        else{
            
            sender.setTitle("Less than:", for: UIControlState.normal)
            
        }
    
    }
    
    
    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
     //   let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        
        //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
        //tap.cancelsTouchesInView = false
        
   //     view.addGestureRecognizer(tap)
        // Do any additional setup after loading the view, typically from a nib.
    
        caloriesTextField.delegate = self
        fatTextField.delegate = self
        carbsTextField.delegate = self
        proteinTextField.delegate = self
    }
    
    //func updateTextFields(){
        
        
   // }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        caloriesInputed = caloriesTextField.text
        fatInputed = fatTextField.text
        carbsInputed = carbsTextField.text
        proteinInputed = proteinTextField.text
        
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "searchResultsSegue"{
            
            let detailVC = segue.destination as! SearchTableViewController
            //let indexPath = tableView.indexPath(for: sender as! UITableViewCell)!
            
            detailVC.searchCalories = caloriesInputed
            detailVC.searchProtein = proteinInputed
            detailVC.searchFat = fatInputed
            detailVC.searchCarbs = carbsInputed
            
            if caloriesButton.titleLabel?.text == "Less than:"{
                
                //lessThanCalories = true
                detailVC.lessthanCalories = true
            }
            
            else{
                detailVC.lessthanCalories = false
            }
            
            if fatButton.titleLabel?.text == "Less than:"{
                
                detailVC.lessthanFat = true
            }
            else{
                detailVC.lessthanFat = false
            }
            
            if carbsButton.titleLabel?.text == "Less than:"{
                
                //lessThanCalories = true
                detailVC.lessthanCarbs = true
            }
                
            else{
                detailVC.lessthanCarbs = false
            }
            if proteinButton.titleLabel?.text == "Less than:"{
                
                //lessThanCalories = true
                detailVC.lessthanProtein = true
            }
                
            else{
                detailVC.lessthanProtein = false
            }
            
            
         //   detailVC.title = restaurantList[indexPath.row]
            //detailVC.selectedRestaurant = restaurantList[indexPath.row]
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


//
//  Restaurants.swift
//  Project1
//
//  Created by Israel Quinonez on 3/12/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import Foundation

class Restaurants{
    var restaurantsData = [String: [String]]()
    var restaurants = [String]()

}

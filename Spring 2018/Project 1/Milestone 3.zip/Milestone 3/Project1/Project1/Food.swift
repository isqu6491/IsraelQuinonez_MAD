//
//  Food.swift
//  Project1
//
//  Created by Israel Quinonez on 3/12/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import Foundation
class Food{
    
    var name = [String]()
    var nameData = [String: [String]]()
    
    var calories = [Int]()
    var caloriesData = [String: [Int]]()
    
    var fat: Int?
    var carbs: Int?
    var protein: Int?
}

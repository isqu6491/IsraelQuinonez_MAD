//
//  Food1.swift
//  Project1
//
//  Created by Israel Quinonez on 3/14/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import Foundation

class Food1{
    
    var foodData = [[String: String]]()
   var name: String?
    var restaurant: String?
    
    var calories: Int?
  
    
    var fat: Int?
    var carbs: Int?
    var protein: Int?
    
    
    
}

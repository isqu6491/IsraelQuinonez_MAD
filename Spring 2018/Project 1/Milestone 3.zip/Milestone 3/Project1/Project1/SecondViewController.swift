//
//  SecondViewController.swift
//  Project1
//
//  Created by Israel Quinonez on 2/27/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import UIKit

class SecondViewController: UITableViewController {
    
    //var restaurantList = Restaurants()
    
    //var foodList = Food()
    
    //var itemList = [Food1()]
    
    var foodData1 = Food1()
    
    var restaurantList = [String]()

    override func viewDidLoad() {
        
        super.viewDidLoad()
  
                
                
        
                if let pathURL = Bundle.main.url(forResource: "food1", withExtension: "plist"){
                    let plistdecoder = PropertyListDecoder()
                    do{
                        let data = try Data(contentsOf: pathURL)
                        foodData1.foodData = try plistdecoder.decode([[String: String]].self, from: data)
                        print(foodData1.foodData)
                        let number = foodData1.foodData.count
                        for i in 0...number-1{
                            let restaurantToAdd = foodData1.foodData[i]["Restaurant"]

                           
                            if restaurantList.contains(restaurantToAdd!){
                                
                            }
                            else{
                            
                                restaurantList.append(restaurantToAdd!)
                            }
                        }
                        
                        print(restaurantList)
                        
                        
                            
                        
                       
                    }
                        
                        
                    catch{
                        print(error)
                    }
                
                
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cellidentifier", for: indexPath)
        
       // let title = foodData1.foodData[indexPath.row]
        
     
        //cell.textLabel?.text = title["Restaurant"]
        cell.textLabel?.text = restaurantList[indexPath.row]

        return cell
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return restaurantList.count
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "foodlistSegue"{
            
            let detailVC = segue.destination as! FoodListTableViewController
            let indexPath = tableView.indexPath(for: sender as! UITableViewCell)!
            
            detailVC.title = restaurantList[indexPath.row]
            detailVC.selectedRestaurant = restaurantList[indexPath.row]
            
        }
    }


}


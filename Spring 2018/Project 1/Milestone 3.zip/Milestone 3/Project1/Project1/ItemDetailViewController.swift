//
//  ItemDetailViewController.swift
//  Project1
//
//  Created by Israel Quinonez on 3/11/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import UIKit


class ItemDetailViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var restaurantLabel: UILabel!
    
    var foodItem = Food1()
    var selectedFood: String?
    var selectedCalories: String?
    var selectedFat: String?
    var selectedCarbs: String?
    var selectedProtein: String?
    
    
    let nutritionCategories = ["Calories","Fat", "Carbs", "Protein"]

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return nutritionCategories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "nutritionCell", for: indexPath)
        cell.textLabel?.text = nutritionCategories[indexPath.row]
        
        let currentCellTitle = cell.textLabel?.text
        
        if (currentCellTitle == "Calories"){
        cell.detailTextLabel?.text = selectedCalories
        }
        
        else if (currentCellTitle == "Fat"){
            cell.detailTextLabel?.text = selectedFat

        }
        
        else if (currentCellTitle == "Carbs"){
            
            cell.detailTextLabel?.text = selectedCarbs

        }
        else{
            
            cell.detailTextLabel?.text = selectedProtein

        }
        
        return cell
    }
    

    @IBOutlet weak var nutritionTableView: UITableView!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let pathURL = Bundle.main.url(forResource: "food1", withExtension: "plist"){
            let plistdecoder = PropertyListDecoder()
            do{
                let data = try Data(contentsOf: pathURL)
                foodItem.foodData = try plistdecoder.decode([[String: String]].self, from: data)
                print(foodItem.foodData)
                
                
                
                let number = foodItem.foodData.count
                for i in 0...number-1{
                    //let foodToAdd = selectedFoodList.foodData[i]["Name"]
                    
                    
                    if (foodItem.foodData[i]["Name"] == selectedFood!){
                       
                        selectedCalories = foodItem.foodData[i]["Calories"]
                        selectedFat = foodItem.foodData[i]["Fat"]
                        selectedCarbs = foodItem.foodData[i]["Carbs"]
                        selectedProtein = foodItem.foodData[i]["Protein"]
                        restaurantLabel.text = foodItem.foodData[i]["Restaurant"]

                        
                    }
                    else{
                        
                    }
                }
                
                
                
                
                
                
            }
                
                
            catch{
                print(error)
            }
        }
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        titleLabel.text? = selectedFood!
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

package com.example.mac.lab_7_israel_quinonez;

/**
 * Created by Mac on 4/16/18.
 */
import java.util.Arrays;
import java.util.ArrayList;

public class Device {

    private String category;
    private ArrayList<String> devicelist = new ArrayList<>();

    private Device(String cat, ArrayList<String> devices){

        this.category = cat;
        this.devicelist = new ArrayList<String>(devices);
    }

    public static final Device[] devices = {


            new Device("Phones", new ArrayList<String>(Arrays.asList("Iphone SE", "Iphone 6s", "Iphone 6s Plus", "Iphone 7", "Iphone 7 Plus", "Iphone 8","Iphone 8 Plus","Iphone X"))),
            new Device("Laptops", new ArrayList<String>(Arrays.asList("MacBook Air", "MacBook 12", "MacBook Pro 13", "MacBook Pro 15"))),
            new Device("Tablets", new ArrayList<String>(Arrays.asList("IPad Mini 4","IPad 9.7", "IPad Pro 9.7","IPad Pro 10.5","IPad Pro 12.9"))),
            new Device("Desktops", new ArrayList<String>(Arrays.asList("IMac 21.7","IMac 4K 21.7","IMac 5K 27","IMac Pro","Mac Pro","Mac Mini"))),
            new Device("Watches", new ArrayList<String>(Arrays.asList("Apple Watch Series 1","Apple Watch Series 3", "Apple Watch Nike+","Apple Watch Edition")))
    };

    public String getCategory(){

        return category;
    }

    public ArrayList<String>getDevicelist(){

        return devicelist;
    }

    public String toString(){
        return this.category;
    }

}

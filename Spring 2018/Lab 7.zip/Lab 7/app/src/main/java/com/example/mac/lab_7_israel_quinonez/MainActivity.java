package com.example.mac.lab_7_israel_quinonez;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends Activity implements CategoryListFragment.CategoryListListener, DeviceDetailFragment.ButtonClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    @Override public void itemClicked(long id){

        DeviceDetailFragment frag = new DeviceDetailFragment();
        frag.setCategory(id);
        FragmentTransaction ft = getFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_container,frag);
        ft.addToBackStack(null);
        ft.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        ft.commit();
    }

    @Override public void onBackPressed(){

       if(getFragmentManager().getBackStackEntryCount()>0){

           getFragmentManager().popBackStack();
       } else {

           super.onBackPressed();
       }
    }

    @Override public void adddeviceclicked(View view){
        DeviceDetailFragment fragment = (DeviceDetailFragment)getFragmentManager().findFragmentById(R.id.fragment_container);
        fragment.addDevice();
    }

}

package com.example.mac.lab_7_israel_quinonez;


import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.app.Fragment;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class DeviceDetailFragment extends Fragment implements View.OnClickListener {


    public DeviceDetailFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        if (savedInstanceState != null){
            categoryId = savedInstanceState.getLong("categoryId");
        }

        return inflater.inflate(R.layout.fragment_device_detail, container, false);

    }
     private ArrayAdapter<String>adapter;


    @Override public void onStart(){

        super.onStart();
        View view = getView();
        ListView listDevices = (ListView)view.findViewById(R.id.devicelistView);

        ArrayList<String> devicelist = new ArrayList<String>();
        devicelist = Device.devices[(int)categoryId].getDevicelist();
        adapter = new ArrayAdapter<String>(getActivity(),android.R.layout.simple_list_item_1, devicelist);
        listDevices.setAdapter(adapter);

        Button addDeviceButton = (Button)view.findViewById(R.id.addDeviceButton);
        addDeviceButton.setOnClickListener(this);
        registerForContextMenu(listDevices);
    }

    private long categoryId;
    public void setCategory(long id){
        this.categoryId = id;

    }
    @Override public void onSaveInstanceState(Bundle savedInstanceState){

        savedInstanceState.putLong("categoryId", categoryId);
    }

    interface ButtonClickListener{
        void adddeviceclicked(View view);
    }

    private ButtonClickListener listener;

    @Override public void onAttach(Context context){

        super.onAttach(context);
        listener =(ButtonClickListener)context;

    }

    @Override public void onClick(View view){

        if (listener != null){
            listener.adddeviceclicked(view);
        }
    }
    public void addDevice(){

        AlertDialog.Builder dialog = new AlertDialog.Builder(getActivity());
        final EditText edittext = new EditText(getActivity());
        dialog.setView(edittext);
        dialog.setTitle("Add Device");
        dialog.setPositiveButton("Add", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int whichButton) {
                String deviceName = edittext.getText().toString();
                if (!deviceName.isEmpty()){
                    Device.devices[(int)categoryId].getDevicelist().add(deviceName);
                    DeviceDetailFragment.this.adapter.notifyDataSetChanged();
                }
            }
        });

        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int whichButton) {

            }
        });
        dialog.show();
    }

    @Override public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){

        super.onCreateContextMenu(menu, view, menuInfo);
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        String devicename = adapter.getItem(adapterContextMenuInfo.position);
        menu.setHeaderTitle("Delete " + devicename);
        menu.add(1,1,1,"Yes");
        menu.add(2,2,2,"No");


    }

    @Override public boolean onContextItemSelected(MenuItem item){
        int itemId = item.getItemId();
        if (itemId == 1){

            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            Device.devices[(int)categoryId].getDevicelist().remove(info.position);
            DeviceDetailFragment.this.adapter.notifyDataSetChanged();

        }
        return true;

    }

}

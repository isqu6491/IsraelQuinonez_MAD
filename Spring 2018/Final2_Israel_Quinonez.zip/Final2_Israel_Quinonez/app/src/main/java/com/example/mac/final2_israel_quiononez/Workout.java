package com.example.mac.final2_israel_quiononez;

import java.util.ArrayList;
import java.util.Arrays;

public class Workout {

    private String workout;
    private ArrayList<String> activities = new ArrayList<>();

    private Workout(String work, ArrayList<String> activ){
        this.workout = work;
        this.activities = new ArrayList<String>(activ);
    }

    public static final Workout[]activities1={

            new Workout("Cardio", new ArrayList<String>(Arrays.asList("Running","Jogging"))),
            new Workout("Strength", new ArrayList<String>(Arrays.asList("Weightlifting"))),
            new Workout("Flexibility", new ArrayList<String>(Arrays.asList("Yoga")))
    };

    public String getWorkout(){

        return workout;
    }
    public ArrayList<String>getActivities(){

        return activities;
    }


    public String toString() {
        return this.workout;
    }
}



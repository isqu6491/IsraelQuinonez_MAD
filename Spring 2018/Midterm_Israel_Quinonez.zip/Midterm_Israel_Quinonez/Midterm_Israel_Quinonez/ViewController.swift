//
//  ViewController.swift
//  Midterm_Israel_Quinonez
//
//  Created by Israel Quinonez on 3/15/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    
    var restaurantList = Restaurants()
   

    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let pathURL = Bundle.main.url(forResource: "restaurants", withExtension: "plist"){
            
            let plistdecoder =  PropertyListDecoder()
            do{
                
               let data = try Data(contentsOf: pathURL)
               restaurantList.restaurants = try plistdecoder.decode([[String : String]].self, from: data)
           //     restaurantList.restaurants = restaurantList.restaurantData.
               
        
                //restaurantList.restaurants = Array(restaurantList.restaurantData.key)
           }catch {
                
               print (error)
           }
        
        
       }
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurantList.restaurants.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellIdentifier", for: indexPath)
        let name = restaurantList.restaurants[indexPath.row]
        cell.textLabel?.text = name["name"]!
        return cell
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail"{
            
            
            let detailVC = segue.destination as! DetailViewController
            let indexPath = tableView.indexPath(for: sender as! UITableViewCell)!
            let name = restaurantList.restaurants[indexPath.row]
            detailVC.title = name ["name"]!
            detailVC.selectedRestaurant = indexPath.row
            detailVC.url = name["url"]!
            
            
     
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


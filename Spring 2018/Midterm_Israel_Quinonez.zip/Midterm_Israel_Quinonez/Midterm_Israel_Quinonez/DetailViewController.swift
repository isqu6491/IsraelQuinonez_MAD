//
//  DetailViewController.swift
//  Midterm_Israel_Quinonez
//
//  Created by Israel Quinonez on 3/15/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import UIKit
import WebKit

class DetailViewController: UIViewController, WKNavigationDelegate {

    @IBOutlet var webSpinner: UIActivityIndicatorView!
    @IBOutlet var webView: WKWebView!
    
    var urlPath: String?
    
    var urlList = [String]()
    var selectedRestaurant = 0
    var restaurantListDetail = Restaurants()
    var url: String!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        webView.navigationDelegate = self 
        

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        loadWebPage(_urlString: url)
    
    }
    
    func loadWebPage(_urlString: String){
        let myurl = URL(string: _urlString)
        let request = URLRequest(url: myurl!)
        webView.load(request)
        
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation:WKNavigation!){
        
        webSpinner.startAnimating()
    }
    
    func webView(_webView: WKWebView, didFinish navigation: WKNavigation!){
        
        webSpinner.startAnimating()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  Restaurants.swift
//  Midterm_Israel_Quinonez
//
//  Created by Israel Quinonez on 3/15/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import Foundation

class Restaurants{
    
    
    var restaurants = [[String:String]]()
}

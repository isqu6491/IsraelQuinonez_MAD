package com.example.mac.lab9_israel_quinonez;

public class shoppingListItem {
    private String id;
    private String name;
    private String notes;

    public shoppingListItem(){

    }

    public shoppingListItem(String newid, String newName, String newNotes){

        id = newid;
        name = newName;
        notes = newNotes;


    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getNotes() {
        return notes;
    }

    public String toString(){
        return this.name;

    }
}

package com.example.mac.lab9_israel_quinonez;


import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.ContextMenu;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    FirebaseDatabase database = FirebaseDatabase.getInstance();
    DatabaseReference ref = database.getReference();
    DatabaseReference shoppingRef = database.getReference("shopping-list-56941");

    List shopping = new ArrayList<>();
    ArrayAdapter<shoppingListItem>listAdapter;

    String notesExtra;
    String notesToSend;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                LinearLayout layout = new LinearLayout(MainActivity.this);
                layout.setOrientation(LinearLayout.VERTICAL);

                final EditText nameEditText = new EditText(MainActivity.this);
                nameEditText.setHint("Item name");
                layout.addView(nameEditText);
                AlertDialog.Builder dialog = new AlertDialog.Builder(MainActivity.this);
                dialog.setTitle("Add shopping list item");
                dialog.setView(layout);
                dialog.setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String itemName = nameEditText.getText().toString();
                        if (itemName.trim().length()>0){

                            String key = shoppingRef.push().getKey();
                            String notes = "";
                            shoppingListItem newItem = new shoppingListItem(key, itemName, notes);
                            shoppingRef.child(key).child("name").setValue(newItem.getName());
                            shoppingRef.child(key).child("notes").setValue(newItem.getNotes());
                        }
                    }
                });
                dialog.setNegativeButton("Cancel", null);
                dialog.show();


            }
        });

        final ListView shoppingList = (ListView)findViewById(R.id.listView);

        listAdapter = new ArrayAdapter<shoppingListItem>(this, android.R.layout.simple_list_item_1,shopping);
        shoppingList.setAdapter(listAdapter);

        ValueEventListener firebaseListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                shopping.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){

                    String newId = snapshot.getKey();
                    shoppingListItem shippingItem = snapshot.getValue(shoppingListItem.class);
                    shoppingListItem newItem = new shoppingListItem(newId, shippingItem.getName(), shippingItem.getNotes());
                    shopping.add(newItem);
                }
                listAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.w("oncreate","Failed to read value", databaseError.toException());

            }
        };

        shoppingRef.addValueEventListener(firebaseListener);
        registerForContextMenu(shoppingList);

        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                shoppingListItem itemTapped = (shoppingListItem)shopping.get(position);
                String stringToPass = itemTapped.getName();

                Intent intent = new Intent(MainActivity.this, NotesActivity.class);
                intent.putExtra("passedString", stringToPass);

                startActivityForResult(intent,999);

                //startActivity(intent);
            }
        };
        shoppingList.setOnItemClickListener(itemClickListener);





    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override public void onCreateContextMenu(ContextMenu menu, View view, ContextMenu.ContextMenuInfo menuInfo){

        super.onCreateContextMenu(menu, view, menuInfo);
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        String itemname = ((TextView)adapterContextMenuInfo.targetView).getText().toString();
        menu.setHeaderTitle("Delete " + itemname);
        menu.add(1,1,1,"Yes");
        menu.add(2,2,2,"No");
    }

    @Override public boolean onContextItemSelected(MenuItem item){
        int itemId = item.getItemId();
        if (itemId == 1){

            AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo)item.getMenuInfo();
            shoppingListItem selectedItem = (shoppingListItem)shopping.get(info.position);
            String itemid = selectedItem.getId();
            shoppingRef.child(itemid).removeValue();

        }
        return true;

    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data){
    if (requestCode == 999 && resultCode == RESULT_OK){
        notesExtra = data.getStringExtra("message");

    }

    }


}

package com.example.mac.lab9_israel_quinonez;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class NotesActivity extends Activity {
    private String itemSelectedName;
    private String noteToadd;
    private String saved;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);


        TextView itemName = (TextView)findViewById(R.id.Title);
        itemSelectedName = getIntent().getStringExtra("passedString");
        itemName.setText(itemSelectedName);



    }

    public void ButtonClick(android.view.View view){
        if(saved == null) {
            EditText newNote = (EditText) findViewById(R.id.textEdit);
            noteToadd = newNote.getText().toString();
            TextView savedNote = (TextView) findViewById(R.id.savedNote);
            saved = noteToadd;
            savedNote.setText(saved);
        }
        else {

            EditText newNote = (EditText) findViewById(R.id.textEdit);
            noteToadd = newNote.getText().toString();
            TextView savedNote = (TextView) findViewById(R.id.savedNote);
            saved = saved  + noteToadd;
            savedNote.setText(saved);


        }



    }

    @Override
    public void onBackPressed() {
        Intent i = new Intent();
        i.putExtra("message",saved);
        setResult(RESULT_OK,i);
        finish();
    }
}

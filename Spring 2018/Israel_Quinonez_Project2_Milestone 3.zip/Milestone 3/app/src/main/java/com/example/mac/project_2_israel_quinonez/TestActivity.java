package com.example.mac.project_2_israel_quinonez;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

public class TestActivity extends Activity {
    private Button submitButton;

    /*private RadioButton oneA;
    private RadioButton oneB;
    private RadioButton twoA;
    private RadioButton twoB;
    private RadioButton threeA;
    private RadioButton threeB;
    private RadioButton fourA;
    private RadioButton fourB;
    private RadioButton fiveA;
    private RadioButton fiveB;
    private RadioButton sixA;
    private RadioButton sixB;
    private RadioButton sevenA;
    private RadioButton sevenB;
    private RadioButton eightA;
    private RadioButton eightB;
    private RadioButton nineA;
    private RadioButton nineB;
    private RadioButton tenA;
    private RadioButton tenB;
    private RadioButton elevenA;
    private RadioButton elevenB;
    private RadioButton twelveA;
    private RadioButton twelveB;
    private RadioButton thirteenA;
    private RadioButton thirteenB;
    private RadioButton fourteenA;
    private RadioButton fourteenB;
    private RadioButton fifteenA;
    private RadioButton fifteenB;
    private RadioButton sixteenA;
    private RadioButton sixteenB;
    private RadioButton seventeenA;
    private RadioButton seventeenB;
    private RadioButton eighteenA;
    private RadioButton eighteenB;
    private RadioButton nineteenA;
    private RadioButton nineteenB;
    private RadioButton twentyA;
    private RadioButton twentyB;

    */

    private TextView resultLabel;
    private int firstLetterCount = 0;
    private int secondLetterCount = 0;
    private int thirdLetterCount = 0;
    private int fourthLetterCount = 0;
    private String firstLetter;
    private String secondLetter;
    private String thirdLetter;
    private String fourthLetter;

    private String personalityTypeResult;

    int count = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        submitButton = (Button)findViewById(R.id.submitbutton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitResults();
            }
        });
    }

    public void submitResults(){


        RadioButton oneA = (RadioButton)findViewById(R.id.oneA);
        RadioButton oneB = (RadioButton)findViewById(R.id.oneB);
        RadioButton twoA = (RadioButton)findViewById(R.id.twoA);
        RadioButton twoB = (RadioButton)findViewById(R.id.twoB);
        RadioButton threeA = (RadioButton)findViewById(R.id.threeA);
        RadioButton threeB = (RadioButton)findViewById(R.id.threeB);
        RadioButton fourA = (RadioButton)findViewById(R.id.fourA);
        RadioButton fourB = (RadioButton)findViewById(R.id.fourB);
        RadioButton fiveA = (RadioButton)findViewById(R.id.fiveA);
        RadioButton fiveB = (RadioButton)findViewById(R.id.fiveB);
        RadioButton sixA = (RadioButton)findViewById(R.id.sixA);
        RadioButton sixB = (RadioButton)findViewById(R.id.sixB);
        RadioButton sevenA = (RadioButton)findViewById(R.id.sevenA);
        RadioButton sevenB = (RadioButton)findViewById(R.id.sevenB);
        RadioButton eightA = (RadioButton)findViewById(R.id.eightA);
        RadioButton eightB = (RadioButton)findViewById(R.id.eightB);
        RadioButton nineA = (RadioButton)findViewById(R.id.nineA);
        RadioButton nineB = (RadioButton)findViewById(R.id.nineB);
        RadioButton tenA = (RadioButton)findViewById(R.id.tenA);
        RadioButton tenB = (RadioButton)findViewById(R.id.tenB);
        RadioButton elevenA = (RadioButton)findViewById(R.id.elevenA);
        RadioButton elevenB = (RadioButton)findViewById(R.id.elevenB);
        RadioButton twelveA = (RadioButton)findViewById(R.id.twelveA);
        RadioButton twelveB = (RadioButton)findViewById(R.id.twelveB);
        RadioButton thirteenA = (RadioButton)findViewById(R.id.thirteenA);
        RadioButton thirteenB = (RadioButton)findViewById(R.id.thirteenB);
        RadioButton fourteenA = (RadioButton)findViewById(R.id.fourteenA);
        RadioButton fourteenB = (RadioButton)findViewById(R.id.fourteenB);
        RadioButton fifteenA = (RadioButton)findViewById(R.id.fifteenA);
        RadioButton fifteenB = (RadioButton)findViewById(R.id.fifteenB);
        RadioButton sixteenA = (RadioButton)findViewById(R.id.sixteenA);
        RadioButton sixteenB = (RadioButton)findViewById(R.id.sixteenB);
        RadioButton seventeenA = (RadioButton)findViewById(R.id.seventeenA);
        RadioButton seventeenB = (RadioButton)findViewById(R.id.seventeenB);
        RadioButton eighteenA = (RadioButton)findViewById(R.id.eighteenA);
        RadioButton eighteenB = (RadioButton)findViewById(R.id.eighteenB);
        RadioButton nineteenA = (RadioButton)findViewById(R.id.nineteenA);
        RadioButton nineteenB = (RadioButton)findViewById(R.id.nineteenB);
        RadioButton twentyA = (RadioButton)findViewById(R.id.twentyA);
        RadioButton twentyB = (RadioButton)findViewById(R.id.twentyB);

        resultLabel = (TextView)findViewById(R.id.resultText);


        if (oneA.isChecked()){

            firstLetterCount++;

        }else {firstLetterCount--;}

        if (twoA.isChecked()){

            secondLetterCount++;

        }else {secondLetterCount--;}

        if (threeA.isChecked()){

            thirdLetterCount++;

        }else {thirdLetterCount--;}

        if (fourA.isChecked()){

            fourthLetterCount++;

        }else {fourthLetterCount--;}

        if (fiveA.isChecked()){

            firstLetterCount++;

        }else {firstLetterCount--;}

        if (sixA.isChecked()){

            secondLetterCount++;

        }else {secondLetterCount--;}

        if (sevenA.isChecked()){

            thirdLetterCount++;

        }else {thirdLetterCount--;}

        if (eightA.isChecked()){

            fourthLetterCount++;

        }else {fourthLetterCount--;}

        if (nineA.isChecked()){

            firstLetterCount++;

        }else {firstLetterCount--;}

        if (tenA.isChecked()){

            secondLetterCount++;

        }else {secondLetterCount--;}

        if (elevenA.isChecked()){

            thirdLetterCount++;

        }else {thirdLetterCount--;}

        if (twelveA.isChecked()){

            fourthLetterCount++;

        }else {fourthLetterCount--;}

        if (thirteenA.isChecked()){

            firstLetterCount++;

        }else {firstLetterCount--;}

        if (fourteenA.isChecked()){

            secondLetterCount++;

        }else {secondLetterCount--;}

        if (fifteenA.isChecked()){

            thirdLetterCount++;

        }else {thirdLetterCount--;}

        if (sixteenA.isChecked()){

            fourthLetterCount++;

        }else {fourthLetterCount--;}

        if (seventeenA.isChecked()){

            firstLetterCount++;

        }else {firstLetterCount--;}

        if (eighteenA.isChecked()){

            secondLetterCount++;

        }else {secondLetterCount--;}

        if (nineteenA.isChecked()){

            thirdLetterCount++;

        }else {thirdLetterCount--;}

        if (twentyA.isChecked()){

            fourthLetterCount++;

        }else {fourthLetterCount--;}


        if (firstLetterCount<1){

            firstLetter = "I";
        }
        else {firstLetter = "E";}

        if (secondLetterCount<1){

            secondLetter = "N";
        }
        else {secondLetter = "S";}

        if (thirdLetterCount<1){
            thirdLetter = "F";
        }
        else {thirdLetter = "T";}

        if (fourthLetterCount <1){

            fourthLetter="P";
        }
        else {fourthLetter = "J";}

        personalityTypeResult = String.valueOf(firstLetter+secondLetter+thirdLetter+fourthLetter);

        if (personalityTypeResult.equals("INTJ")){

            resultLabel.setText("Your type is " + personalityTypeResult);
        }
        else {

            resultLabel.setText("Your type is " + personalityTypeResult);
        }

        /*
        if ((firstLetterCount >1)&&(secondLetterCount>1)&&(thirdLetterCount>1)&&(fourthLetterCount>1)){

            personalityTypeResult = "ESTJ";
        }
        else if ((firstLetterCount >1)&&(secondLetterCount>1)&&(thirdLetterCount>1)&&(fourthLetterCount<1)){

            personalityTypeResult = "ESTP";
        }
        else if ((firstLetterCount >1)&&(secondLetterCount>1)&&(thirdLetterCount<1)&&(fourthLetterCount<1)){

            personalityTypeResult = "EST"
        }
        */

        firstLetterCount = 0;
        secondLetterCount = 0;
        thirdLetterCount = 0;
        fourthLetterCount= 0;













    }
}

package com.example.mac.project_2_israel_quinonez;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;

public class MainActivity extends Activity implements View.OnClickListener {



    private Button testButton;
    public static final String EXTRA_TEXT = "com.example.mac.project_2_israel_quinonez.EXTRA_TEXT";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        testButton = (Button)findViewById(R.id.testButton);
        testButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTestActivity();
            }
        });

        ImageButton INTJbutton1 = (ImageButton) findViewById(R.id.INTJbutton1);
        ImageButton INTPbutton2 = (ImageButton) findViewById(R.id.INTPbutton2);
        ImageButton ENTJbutton3 = (ImageButton) findViewById(R.id.ENTJbutton3);
        ImageButton ENTPButton4 = (ImageButton) findViewById(R.id.ENTPButton4);
        ImageButton INFJbutton5 = (ImageButton) findViewById(R.id.INFJbutton5);
        ImageButton INFPbutton6 = (ImageButton) findViewById(R.id.INFPbutton6);
        ImageButton ENFJbutton7_ = (ImageButton) findViewById(R.id.ENFJbutton7_);
        ImageButton ENFPbutton8 = (ImageButton) findViewById(R.id.ENFPbutton8);
        ImageButton ISTJbutton9 = (ImageButton) findViewById(R.id.ISTJbutton9);
        ImageButton ISFJbutton10 = (ImageButton) findViewById(R.id.ISFJbutton10);
        ImageButton ESTJbutton11 = (ImageButton) findViewById(R.id.ESTJbutton11);
        ImageButton ESFJbutton12 = (ImageButton) findViewById(R.id.ESFJbutton12);
        ImageButton ISTPbutton13 = (ImageButton) findViewById(R.id.ISTPbutton13);
        ImageButton ISFPbutton14 = (ImageButton) findViewById(R.id.ISFPbutton14);
        ImageButton ESTPbutton15 = (ImageButton) findViewById(R.id.ESTPbutton15);
        ImageButton ESFPbutton16 = (ImageButton) findViewById(R.id.ESFPbutton16);


        INTJbutton1.setOnClickListener(this);
        INTPbutton2.setOnClickListener(this);
        ENTJbutton3.setOnClickListener(this);
        ENTPButton4.setOnClickListener(this);
        INFJbutton5.setOnClickListener(this);
        INFPbutton6.setOnClickListener(this);
        ENFJbutton7_.setOnClickListener(this);
        ENFPbutton8.setOnClickListener(this);
        ISTJbutton9.setOnClickListener(this);
        ISFJbutton10.setOnClickListener(this);
        ESTJbutton11.setOnClickListener(this);
        ESFJbutton12.setOnClickListener(this);
        ISTPbutton13.setOnClickListener(this);
        ISFPbutton14.setOnClickListener(this);
        ESTPbutton15.setOnClickListener(this);
        ESFPbutton16.setOnClickListener(this);




    }

    public void openTestActivity(){
        Intent intent = new Intent(this, TestActivity.class);
        startActivity(intent);

    }

    @Override
    public void onClick(View v) {

        String passText;
        Intent intent = new Intent(this, TypeDetailActivity.class);


        switch (v.getId()){

            case R.id.INTJbutton1:
                intent.putExtra(EXTRA_TEXT, "INTJ" );
                break;
            case R.id.INTPbutton2:
                intent.putExtra(EXTRA_TEXT, "INTP" );
                break;
            case R.id.ENTJbutton3:
                intent.putExtra(EXTRA_TEXT, "ENTJ" );
                break;

            case R.id.ENTPButton4:
                intent.putExtra(EXTRA_TEXT, "ENTP" );
                break;
            case R.id.INFJbutton5:
                intent.putExtra(EXTRA_TEXT, "INFJ" );
                break;
            case R.id.INFPbutton6:
                intent.putExtra(EXTRA_TEXT, "INFP" );
                break;
            case R.id.ENFJbutton7_:
                intent.putExtra(EXTRA_TEXT, "ENFJ" );
                break;
            case R.id.ENFPbutton8:
                intent.putExtra(EXTRA_TEXT, "ENFP" );
                break;
            case R.id.ISTJbutton9:
                intent.putExtra(EXTRA_TEXT, "ISTJ" );
                break;
            case R.id.ISFJbutton10:
                intent.putExtra(EXTRA_TEXT, "ISFJ" );
                break;
            case R.id.ESTJbutton11:
                intent.putExtra(EXTRA_TEXT, "ESTJ" );
                break;
            case R.id.ESFJbutton12:
                intent.putExtra(EXTRA_TEXT, "ESFJ" );
                break;
            case R.id.ISTPbutton13:
                intent.putExtra(EXTRA_TEXT, "ISTP" );
                break;
            case R.id.ISFPbutton14:
                intent.putExtra(EXTRA_TEXT, "ISFP" );
                break;
            case R.id.ESTPbutton15:
                intent.putExtra(EXTRA_TEXT, "ESTP" );
                break;
            case R.id.ESFPbutton16:
                intent.putExtra(EXTRA_TEXT, "ESFP" );
                break;

            default:
                intent.putExtra(EXTRA_TEXT, "failure" );


        }

        startActivity(intent);

    }
}

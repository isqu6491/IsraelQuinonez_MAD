package com.example.mac.project_2_israel_quinonez;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class TypeDetailActivity extends Activity {

    private TextView personalityTypeTextView;
    private String personalityType;
    private TextView typeDescription;
    private TextView weaknesses;
    private TextView strengths;
    private TextView cognativeDescription;
    private ImageView cognativePicture;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_type_detail);

        personalityTypeTextView = (TextView)findViewById(R.id.personalityType);
        typeDescription = (TextView)findViewById(R.id.descriptionText);
        weaknesses = (TextView)findViewById(R.id.weaknessesText);
        strengths = (TextView)findViewById(R.id.strengthsText);
        cognativeDescription = (TextView)findViewById(R.id.cognativeFunctionsText);
        cognativePicture = (ImageView)findViewById(R.id.imageView2);


        Intent intent = getIntent();
        personalityType = intent.getStringExtra(MainActivity.EXTRA_TEXT);

        FillData();
        personalityTypeTextView.setText(personalityType);



    }

    public void FillData(){

        switch (personalityType){

            case "INTJ":
                typeDescription.setText(R.string.INTJdescription);
                strengths.setText(R.string.INTJstrengths2);
                weaknesses.setText(R.string.INTJweakness);
                cognativeDescription.setText(R.string.INTJCognative);
                cognativePicture.setImageResource(R.drawable.intjcognative);
                break;
            case "INTP":
                typeDescription.setText(R.string.INTPdescription);
                strengths.setText(R.string.INTPstrengths2);
                weaknesses.setText(R.string.INTPweakness);
                cognativeDescription.setText(R.string.INTPCognative);
                cognativePicture.setImageResource(R.drawable.intpcognative);

                break;

            case "ENTJ":
                typeDescription.setText(R.string.ENTJdescription);
                strengths.setText(R.string.ENTJstrengths2);
                weaknesses.setText(R.string.ENTJweakness);
                cognativeDescription.setText(R.string.ENTJCognative);
                cognativePicture.setImageResource(R.drawable.entjcognative);

                break;
            case "ENTP":
                typeDescription.setText(R.string.ENTPdescription);
                strengths.setText(R.string.ENTPstrengths2);
                weaknesses.setText(R.string.ENTPweakness);
                cognativeDescription.setText(R.string.ENTPCognative);
                cognativePicture.setImageResource(R.drawable.entpcognative);

                break;
            case "INFJ":
                typeDescription.setText(R.string.INFJdescription);
                strengths.setText(R.string.INFJstrengths2);
                weaknesses.setText(R.string.INFJweakness);
                cognativeDescription.setText(R.string.INFJCognative);
                cognativePicture.setImageResource(R.drawable.infjcognative);

                break;
            case "INFP":
                typeDescription.setText(R.string.INFPdescription);
                strengths.setText(R.string.INFPstrengths2);
                weaknesses.setText(R.string.INFPweakness);
                cognativeDescription.setText(R.string.INFPCognative);
                cognativePicture.setImageResource(R.drawable.infpcognitive);

                break;
            case "ENFJ":
                typeDescription.setText(R.string.ENFJdescription);
                strengths.setText(R.string.ENFJstrengths2);
                weaknesses.setText(R.string.ENFJweakness);
                cognativeDescription.setText(R.string.ENFJCognative);
                cognativePicture.setImageResource(R.drawable.enfjcognative);

                break;
            case "ENFP":
                typeDescription.setText(R.string.ENFPdescription);
                strengths.setText(R.string.ENFPstrengths2);
                weaknesses.setText(R.string.ENFPweakness);
                cognativeDescription.setText(R.string.ENFPCognative);
                cognativePicture.setImageResource(R.drawable.enfpcognative);

                break;
            case "ISTJ":
                typeDescription.setText(R.string.ISTJdescription);
                strengths.setText(R.string.ISTJstrengths2);
                weaknesses.setText(R.string.ISTJweakness);
                cognativeDescription.setText(R.string.ISTJCognative);
                cognativePicture.setImageResource(R.drawable.istjcognative);

                break;
            case "ISFJ":
                typeDescription.setText(R.string.ISFJdescription);
                strengths.setText(R.string.ISFJstrengths2);
                weaknesses.setText(R.string.ISFJweakness);
                cognativeDescription.setText(R.string.ISFJCognative);
                cognativePicture.setImageResource(R.drawable.isfjcognative);

                break;
            case "ESTJ":
                typeDescription.setText(R.string.ESTJdescription);
                strengths.setText(R.string.ESTJstrengths2);
                weaknesses.setText(R.string.ESTJweakness);
                cognativeDescription.setText(R.string.ESTJCognative);
                cognativePicture.setImageResource(R.drawable.estjcognative);

                break;
            case "ESFJ":
                typeDescription.setText(R.string.ESFJdescription);
                strengths.setText(R.string.ESFJstrengths2);
                weaknesses.setText(R.string.ESFJweakness);
                cognativeDescription.setText(R.string.ESFJCognative);
                cognativePicture.setImageResource(R.drawable.esfjcognative);

                break;
            case "ISTP":
                typeDescription.setText(R.string.ISTPdescription);
                strengths.setText(R.string.ISTPstrengths2);
                weaknesses.setText(R.string.ISTPweakness);
                cognativeDescription.setText(R.string.ISTPCognative);
                cognativePicture.setImageResource(R.drawable.istpcognative);

                break;
            case "ISFP":
                typeDescription.setText(R.string.ISFPdescription);
                strengths.setText(R.string.ISFPstrengths2);
                weaknesses.setText(R.string.ISFPweakness);
                cognativeDescription.setText(R.string.ISFPCognative);
                cognativePicture.setImageResource(R.drawable.isfpcognative);

                break;
            case "ESTP":
                typeDescription.setText(R.string.ESTPdescription);
                strengths.setText(R.string.ESTPstrengths2);
                weaknesses.setText(R.string.ESTPweakness);
                cognativeDescription.setText(R.string.ESTPCognative);
                cognativePicture.setImageResource(R.drawable.estpcognative);

                break;
            case "ESFP":
                typeDescription.setText(R.string.ESFPdescription);
                strengths.setText(R.string.ESFPstrengths2);
                weaknesses.setText(R.string.ESFPweakness);
                cognativeDescription.setText(R.string.ESFPCognative);
                cognativePicture.setImageResource(R.drawable.esfpcognative);

                break;

            default:


        }

    }





}

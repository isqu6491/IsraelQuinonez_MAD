//
//  Lab_2_Israel_QuinonezTests.swift
//  Lab 2 Israel QuinonezTests
//
//  Created by Israel Quinonez on 2/18/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import XCTest
@testable import Lab_2_Israel_Quinonez

class Lab_2_Israel_QuinonezTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
        }
    }
    
}

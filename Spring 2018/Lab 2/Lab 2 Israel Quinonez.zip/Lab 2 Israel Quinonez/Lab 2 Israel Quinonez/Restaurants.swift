//
//  Restaurants.swift
//  Lab 2 Israel Quinonez
//
//  Created by Israel Quinonez on 2/18/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import Foundation

class Restaurants{
    
    var restaurantData = [String:[String]]()
    var restaurants = [String]()
    
}

//
//  ViewController.swift
//  Lab 2 Israel Quinonez
//
//  Created by Israel Quinonez on 2/18/18.
//  Copyright © 2018 Israel Quinonez. All rights reserved.
//

import UIKit


class ViewController: UITableViewController {
    
    let kfilename = "data2.plist"
    var restaurantList = Restaurants()
    //var searchController : UISearchController!

    
    

    override func viewDidLoad() {
       
        super.viewDidLoad()
        
        let pathURL: URL?
        
        let dirPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let docDir = dirPath[0]
        print(docDir)
        
        let dataFileURL = docDir.appendingPathComponent(kfilename)
        print(dataFileURL)
        
        if FileManager.default.fileExists(atPath: dataFileURL.path){
            pathURL = dataFileURL
        }
        else{
            
            pathURL = Bundle.main.url(forResource: "restaurants", withExtension: "plist")
        }
        
        let  plistdecoder = PropertyListDecoder()
        
        do{
            let data = try Data(contentsOf: pathURL!)
            restaurantList.restaurantData = try plistdecoder.decode([String: [String]].self, from: data)
            restaurantList.restaurants = Array(restaurantList.restaurantData.keys)
            
        }catch{
            print(error)
            
        }
        
        
       
        
      /*  if let pathURL = Bundle.main.url(forResource: "restaurants", withExtension: "plist"){
            let  plistdecoder = PropertyListDecoder()
            do{
                
                let data = try Data(contentsOf: pathURL)
                restaurantList.restaurantData = try
                    plistdecoder.decode([String: [String]].self, from: data)
                
                restaurantList.restaurants = Array(restaurantList.restaurantData.keys)
                
            }catch{
                
                print(error)
            }
        */
            
            navigationController?.navigationBar.prefersLargeTitles = true
            
            let app = UIApplication.shared
            
            NotificationCenter.default.addObserver(self, selector: #selector(ViewController.applicationWillResignActive(_:)), name: NSNotification.Name.UIApplicationWillResignActive, object: app)
            
            
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
   
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return restaurantList.restaurants.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "CellIdentifier", for: indexPath)
        
        cell.textLabel?.text = restaurantList.restaurants[indexPath.row]
        return cell
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "foodsegue"{
            
            let detailVC = segue.destination as! DetailViewController
            let indexPath = tableView.indexPath(for: sender as! UITableViewCell)!
            detailVC.title = restaurantList.restaurants[indexPath.row]
            detailVC.restaurantListDetail=restaurantList
            detailVC.selectedRestaurant = indexPath.row
            
        }
    }
    
    @objc func applicationWillResignActive(_ notification: NSNotification){
        
        let dirPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        
        let docDir = dirPath[0]
        print(docDir)
        
        let dataFileURL = docDir.appendingPathComponent(kfilename)
        print(dataFileURL)
        let plistencoder = PropertyListEncoder()
        plistencoder.outputFormat = .xml
        
        do{
            let data = try plistencoder.encode(restaurantList.restaurantData)
            try data.write(to: dataFileURL)
            
            
            
        }catch{
            
            print(error)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}


package com.example.mac.project2game;

import android.media.Image;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

       requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);
    }

    boolean game;
    int currentRound;
    boolean roundClick;

    int  currentScore1;
    int currentScore2;
    TextView scoreText1;
    TextView scoreText2;
    int currentImage;
    ImageView image;

    private boolean started = false;
    private Handler handler = new Handler();

    private Runnable runnable = new Runnable() {

        @Override
        public void run() {
            //image = (ImageView) findViewById(R.id.imageView);




            Random r = new Random();
            int i1 = r.nextInt(5 - 1 + 1) + 1;


            if (i1 == 1){
               image.setImageResource(R.drawable.goose);
               currentImage = 1;
               roundClick = false;


            }

            else {
                image.setImageResource(R.drawable.duck);
                currentImage = 2;
                roundClick = false;
            }

            currentRound++;


            if(started) {
                start();
            }
        }
    };

    public void stop() {
        started = false;
        handler.removeCallbacks(runnable);
    }

    public void start() {
        started = true;

        handler.postDelayed(runnable, 1000);
    }




    public void buttonOnClick(View view){

        if (game == false){}

        else {
            if (roundClick == true){}

            else {


                switch (view.getId()) {
                    case R.id.button2:
                        roundClick = true;


                        if (currentImage == 1 ) {

                            if (currentScore1 != 4) {
                                currentScore1++;
                                scoreText1.setText("Score:" + String.valueOf(currentScore1));
                            }
                            else {

                                winner(1);
                                currentScore1++;
                                scoreText1.setText("Score:" + String.valueOf(currentScore1));
                            }


                        }
                        else {
                            if (currentScore1 != 0) {
                                currentScore1--;
                                scoreText1.setText("Score" + String.valueOf(currentScore1));
                            }
                            else{}
                        }
                        break;





                    case R.id.button:
                        roundClick = true;


                        if (currentImage == 1 ) {
                            if (currentScore2 != 4) {
                                currentScore2++;
                                scoreText2.setText("Score:" + String.valueOf(currentScore2));
                            }
                            else {

                                winner(2);
                                currentScore2++;
                                scoreText2.setText("Score:" + String.valueOf(currentScore2));

                            }


                        }
                        else {
                            if (currentScore2 != 0) {
                                currentScore2--;
                                scoreText2.setText("Score" + String.valueOf(currentScore2));
                            }
                            else {}
                        }
                        break;


                }
            }
        }

    }


    public void button(View view){

        start();
        game = true;

        currentScore2 = 0;
        currentScore1 = 0;
        scoreText1 = (TextView)findViewById(R.id.textView);
        scoreText2 = (TextView)findViewById(R.id.textView3);
        image = (ImageView) findViewById(R.id.imageView);
        image.setImageResource(R.drawable.duck);


        currentRound = 0;
    }

    public void resetButton(View view){
        if (game) {
            stop();
            currentRound = 0;
            currentScore1 = 0;
            currentScore2 = 0;
            scoreText1.setText("Score: 0");
            scoreText2.setText("Score: 0");
            image = (ImageView) findViewById(R.id.imageView);
            TextView winner = (TextView) findViewById(R.id.textView2);
            winner.setText("");

            image.setImageResource(0);


            game = false;
        }
        else{}
    }

    public void winner(int winnerNumber){
        TextView winner = (TextView) findViewById(R.id.textView2);
        stop();

        image.setImageResource(0);

        if (winnerNumber == 1) {
            winner.setText("Left Player Wins!!");
        }
        else {

            winner.setText("Right Player Wins!!");
        }
    }



}

package com.example.mac.lab5israelquinonez;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.RadioGroup;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void findDish(View view) {
        ToggleButton toggle = (ToggleButton) findViewById(R.id.toggleButton);
        boolean temp = toggle.isChecked();
        RadioGroup dishType = (RadioGroup)findViewById(R.id.radioGroup);
        int type_id = dishType.getCheckedRadioButtonId();

        CheckBox calorieCheckBox = (CheckBox)findViewById(R.id.checkBox1);
        Boolean calorie = calorieCheckBox.isChecked();

        CheckBox proteinCheckBox = (CheckBox)findViewById(R.id.checkBox2);
        Boolean protein = proteinCheckBox.isChecked();

        CheckBox carbCheckBox = (CheckBox)findViewById(R.id.checkBox3);
        Boolean carb = carbCheckBox.isChecked();


        String perfectDish = "test";

        if(type_id == -1){

            Context context = getApplicationContext();
            CharSequence text = "Please select a meal type";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

        }

        else{

            if (temp){
                if(type_id == R.id.radioButton1){
                    perfectDish = "Steak and potatoes";
                    if (calorie){
                        perfectDish = "Chicken and broccoli";
                    }

                    if (protein){
                        perfectDish = "Steak and potatoes";

                    }

                    if (carb){
                        perfectDish = "Steak and broccoli";

                    }

                    if (calorie && protein){
                        perfectDish = "Chicken and beans";

                    }

                    if (calorie && carb){
                        perfectDish = "Chicken and broccoli";

                    }

                    if (protein && carb){
                        perfectDish = "Steak and broccoli";


                    }
                     if (protein && carb && calorie){
                        perfectDish = "Chicken and beans ";


                    }

                }

                else if (type_id == R.id.radioButton2){

                    perfectDish = "Spaghetti and Meatballs";

                    if (calorie){
                        perfectDish = "Organic Spaghetti and meatballs";
                    }

                    if (protein){
                        perfectDish = "Extra meat lasagna";

                    }

                    if (carb){
                        perfectDish = "Meatballs and sauce";

                    }

                    if (calorie && protein){
                        perfectDish = "Organic extra meat lasagna";

                    }

                    if (calorie && carb){
                        perfectDish = "Low fat meatballs and sauce";

                    }

                    if (protein && carb){
                        perfectDish = "Extra meat lasagna";


                    }
                    if (protein && carb && calorie){
                        perfectDish = "low fat meatballs and sauce ";


                    }
                }

                else if (type_id == R.id.radioButton3){

                    perfectDish = "Eggs, bacon and hash browns";

                    if (calorie){
                        perfectDish = "Egg whites and hash browns";
                    }

                    if (protein){
                        perfectDish = "Extra eggs, bacon and hash browns";

                    }

                    if (carb){
                        perfectDish = "Eggs and bacon";

                    }

                    if (calorie && protein){
                        perfectDish = "Extra egg whites and low fat bacon";

                    }

                    if (calorie && carb){
                        perfectDish = "Egg whites and low fat bacon";

                    }

                    if (protein && carb){
                        perfectDish = "Extra eggs and bacon";


                    }
                    if (protein && carb && calorie){
                        perfectDish = "Extra egg whites and low fat bacon ";


                    }

                }

            }

            else{
                if(type_id == R.id.radioButton1){

                    perfectDish = "Strawberry chicken salad w/ dressing";

                    if (calorie){
                        perfectDish = "Strawberry chicken salad";
                    }

                    if (protein){
                        perfectDish = "Strawberry extra chicken salad w/ dressing";

                    }

                    if (carb){
                        perfectDish = "Chicken salad w/ dressing";

                    }

                    if (calorie && protein){
                        perfectDish = "Strawberry extra chicken salad";

                    }

                    if (calorie && carb){
                        perfectDish = "Chicken salad";

                    }

                    if (protein && carb){
                        perfectDish = "Extra chicken salad w/ dressing";


                    }
                    if (protein && carb && calorie){
                        perfectDish = "Extra chicken salad ";


                    }

                }

                else if (type_id == R.id.radioButton2){


                    perfectDish = "BLT sandwich";

                    if (calorie){
                        perfectDish = "BLT sandwich w/ whole wheat bread";
                    }

                    if (protein){
                        perfectDish = "Extra bacon BLT sandwich";

                    }

                    if (carb){
                        perfectDish = "BLT sandwich w/ low carb bread";

                    }

                    if (calorie && protein){
                        perfectDish = "Extra bacon BLT sandwich w/ whole wheat";

                    }

                    if (calorie && carb){
                        perfectDish = "BLT sandwich w/ low carb bread";

                    }

                    if (protein && carb){
                        perfectDish = "Extra bacon BLT sandwich w/ low carb bread";


                    }
                    if (protein && carb && calorie){
                        perfectDish = "Extra bacon BLT sandwich w/ low carb bread";


                    }

                }

                else if (type_id == R.id.radioButton3){

                    perfectDish = "Yogurt & Granola w/ fruit";

                    if (calorie){
                        perfectDish = "Yogurt w/ fruit";
                    }

                    if (protein){
                        perfectDish = "Greek Yogurt & Granola w/ fruit";

                    }

                    if (carb){
                        perfectDish = "Yogurt";

                    }

                    if (calorie && protein){
                        perfectDish = "Greek Yogurt w/ fruit";

                    }

                    if (calorie && carb){
                        perfectDish = "Yogurt";

                    }

                    if (protein && carb){
                        perfectDish = "Greek Yogurt ";


                    }
                    if (protein && carb && calorie){
                        perfectDish = "Greek Yogurt";


                    }

                }



            }

            TextView dishSelection = (TextView)findViewById(R.id.dishTextView);
            dishSelection.setText(perfectDish + " is your recommended dish");

        }




    }
}
